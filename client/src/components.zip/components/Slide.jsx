import "../styles/Slide.scss"

const Slide = () => {
  return (
    <div className="slide">
      <h1>
      Bienvenue ! <br /> Faites de chaque moment un souvenir
      inoubliable.
      </h1>
    </div>
  );
};

export default Slide;